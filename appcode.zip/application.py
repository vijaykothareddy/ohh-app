# from app import app
# from app import run
from flask import Flask, request, render_template
from appcode import run

application = Flask(__name__)

@application.route('/')
@application.route('/index')
def index():
    return render_template('my-form.html')
@application.route('/index', methods=['POST'])
def index_post():
    id = request.form['text']
    id = int(id)
    resp = run.drive(id)
    return resp
    #return id

# run the app.
if __name__ == "__main__":
    # Setting debug to True enables debug output. This line should be
    # removed before deploying a production app.
    application.debug = True
    application.run()