from appcode import run

def test_subordinates():
    assert run.drive(1) == '{"4": "Emily Employee", "3": "Sam Supervisor", "2": "Mary Manager", "5": "Trent Trainer"}'