HTML templates are stored here
